import { MSA_STATUS_LABELS, PROJECT_TYPE_LABELS, PUBLIC_PRIVATE_LABELS, YES_NO_NOT_SURE_LABELS } from "@/lib/catalogs";
import { createProjectAction } from "@/app/app/actions";

export default function NewProjectPage() {
  return (
    <form action={createProjectAction} className="mx-auto max-w-[1120px] space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">New Review</p>
          <h1 className="mt-2 text-3xl font-semibold text-ink">Create project review</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-moss">
            Start with the project facts needed for a subcontract-vs-bid comparison.
          </p>
        </div>
        <button className="button-primary" type="submit">Create review</button>
      </div>

      <section className="card p-8 sm:p-10">
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          <label className="md:col-span-2">
            <span className="field-label">Project name</span>
            <input className="field" name="name" required />
          </label>
          <label className="md:col-span-2">
            <span className="field-label">Project address</span>
            <input className="field" name="projectAddress" required />
          </label>
          <label>
            <span className="field-label">City</span>
            <input className="field" name="city" required />
          </label>
          <label>
            <span className="field-label">State</span>
            <input className="field" name="state" required />
          </label>
          <label>
            <span className="field-label">ZIP</span>
            <input className="field" name="zip" required />
          </label>
          <label>
            <span className="field-label">Trade type</span>
            <input className="field" name="tradeType" required placeholder="Electrical, drywall, civil..." />
          </label>
          <label>
            <span className="field-label">GC name</span>
            <input className="field" name="gcName" required />
          </label>
          <label>
            <span className="field-label">Owner name</span>
            <input className="field" name="ownerName" />
          </label>
          <label>
            <span className="field-label">Contract amount</span>
            <input className="field" name="contractAmount" min="0" step="100" type="number" />
          </label>
          <label>
            <span className="field-label">Bid date</span>
            <input className="field" name="bidDate" type="date" />
          </label>
          <label>
            <span className="field-label">Proposed execution deadline</span>
            <input className="field" name="executionDeadline" type="date" />
          </label>
          <label>
            <span className="field-label">Project type</span>
            <select className="field" name="projectType" defaultValue="commercial">
              {Object.entries(PROJECT_TYPE_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
          <label>
            <span className="field-label">Is there an MSA?</span>
            <select className="field" name="hasMasterServiceAgreement" defaultValue="not-sure">
              {Object.entries(MSA_STATUS_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
          <label>
            <span className="field-label">Public or private work?</span>
            <select className="field" name="publicOrPrivate" defaultValue="not-sure">
              {Object.entries(PUBLIC_PRIVATE_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
          <label>
            <span className="field-label">Prevailing wage involved?</span>
            <select className="field" name="prevailingWageStatus" defaultValue="not-sure">
              {Object.entries(YES_NO_NOT_SURE_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
        </div>
      </section>
    </form>
  );
}
